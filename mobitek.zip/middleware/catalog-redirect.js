export default function ({store, redirect}) {
	return redirect('/catalog');
}
