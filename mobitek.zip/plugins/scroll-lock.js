import Vue from 'vue';
import VBodyScrollLock from 'v-body-scroll-lock';

Vue.use(VBodyScrollLock);
