import Vue from 'vue';

import CustomLink from '../components/global/Link';

Vue.component('clink', CustomLink);
