<template>
	<div class="index-page__bottom-features">
		<div class="index-page__bottom-features__inner">
			<div class="index-page__bottom-features__item">
				<img src="/pics/img/index/fast-delivery.png" :alt="$t('index.bottom-features.fast-delivery')">
				<span>{{ $t('index.bottom-features.fast-delivery') }}</span>
			</div>
			<div class="index-page__bottom-features__item">
				<img src="/pics/img/index/high-quality.png" :alt="$t('index.bottom-features.high-quality')">
				<span>{{ $t('index.bottom-features.high-quality') }}</span>
			</div>
			<div class="index-page__bottom-features__item">
				<img src="/pics/img/index/instant-reply.png" :alt="$t('index.bottom-features.instant-reply')">
				<span>{{ $t('index.bottom-features.instant-reply') }}</span>
			</div>
		</div>
	</div>
</template>
