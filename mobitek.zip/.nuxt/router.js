import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _25e16e0c = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _117af250 = () => interopDefault(import('..\\pages\\catalog.vue' /* webpackChunkName: "pages_catalog" */))
const _f562c4b8 = () => interopDefault(import('..\\pages\\contacts.vue' /* webpackChunkName: "pages_contacts" */))
const _63613c14 = () => interopDefault(import('..\\pages\\product\\index.vue' /* webpackChunkName: "pages_product_index" */))
const _759c1e35 = () => interopDefault(import('..\\pages\\products.vue' /* webpackChunkName: "pages_products" */))
const _459948d1 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _7477337c = () => interopDefault(import('..\\pages\\product\\_id.vue' /* webpackChunkName: "pages_product__id" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _25e16e0c,
    name: "about___en"
  }, {
    path: "/catalog",
    component: _117af250,
    name: "catalog___en"
  }, {
    path: "/contacts",
    component: _f562c4b8,
    name: "contacts___en"
  }, {
    path: "/product",
    component: _63613c14,
    name: "product___en"
  }, {
    path: "/products",
    component: _759c1e35,
    name: "products___en"
  }, {
    path: "/az/",
    component: _459948d1,
    name: "index___az"
  }, {
    path: "/az/about",
    component: _25e16e0c,
    name: "about___az"
  }, {
    path: "/az/catalog",
    component: _117af250,
    name: "catalog___az"
  }, {
    path: "/az/contacts",
    component: _f562c4b8,
    name: "contacts___az"
  }, {
    path: "/az/product",
    component: _63613c14,
    name: "product___az"
  }, {
    path: "/az/products",
    component: _759c1e35,
    name: "products___az"
  }, {
    path: "/ru/",
    component: _459948d1,
    name: "index___ru"
  }, {
    path: "/ru/about",
    component: _25e16e0c,
    name: "about___ru"
  }, {
    path: "/ru/catalog",
    component: _117af250,
    name: "catalog___ru"
  }, {
    path: "/ru/contacts",
    component: _f562c4b8,
    name: "contacts___ru"
  }, {
    path: "/ru/product",
    component: _63613c14,
    name: "product___ru"
  }, {
    path: "/ru/products",
    component: _759c1e35,
    name: "products___ru"
  }, {
    path: "/az/product/:id",
    component: _7477337c,
    name: "product-id___az"
  }, {
    path: "/ru/product/:id",
    component: _7477337c,
    name: "product-id___ru"
  }, {
    path: "/product/:id",
    component: _7477337c,
    name: "product-id___en"
  }, {
    path: "/",
    component: _459948d1,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
