export const API_URI = "https://mobitek.az/api"
