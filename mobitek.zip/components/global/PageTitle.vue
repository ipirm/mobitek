<template>
	<div class="page-title">
		<div class="line"></div>
		<h1>{{ title }}</h1>
		<div class="line"></div>
	</div>
</template>

<script>
export default {
	props: ['title']
}
</script>
