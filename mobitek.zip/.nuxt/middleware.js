const middleware = {}

middleware['catalog-redirect'] = require('..\\middleware\\catalog-redirect.js')
middleware['catalog-redirect'] = middleware['catalog-redirect'].default || middleware['catalog-redirect']

export default middleware
