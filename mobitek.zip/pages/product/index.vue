<template>
	<div class="nope"></div>
</template>

<script>
export default {
	middleware: 'catalog-redirect'
}
</script>
